import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;
import pages.ProductsPage;
import pages.CartPage;

public class EcomTest {
    public static void main(String[] args)throws InterruptedException{

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
        LoginPage login = new LoginPage(driver);
        login.login("standard_user","secret_sauce");
        Thread.sleep(4000);
        ProductsPage product = new ProductsPage(driver);
        product.addProductToCart();
        product.clickCart();
        Thread.sleep(4000);
        CartPage cart = new CartPage(driver);
        if(cart.isProductDisplayed()){
            System.out.println("Product added to cart successfully");
        }else{
            System.out.println("Test Failed");
        }
        Thread.sleep(3000);
        driver.quit();
    }
}
